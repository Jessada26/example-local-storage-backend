const express = require('express')
const createNamespace = require('cls-hooked').createNamespace;

const session = createNamespace('my session');
const app = express()
const port = 3000

function four() {
    const oldValue = session.get('user')
    session.set('user', {
        ...oldValue,
        sarary: '100'
    });
}

function three() {
    session.set('user', {
        name:'rattana jessadapong'
    });
    four()
}

function two( ) {
    session.set('user', {
        name:'jessadapong rattana'
    });
    three()
}

app.get('/', (req, res) => {
    session.run(
        function(){
            two( )
            res.send({data:session.get('user')})
        }
        
    )
    
})


app.listen(port, () => console.log(`listening at http://localhost:${port}`))
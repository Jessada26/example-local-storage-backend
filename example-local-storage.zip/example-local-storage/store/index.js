import store from "store"

function two() {
    store.set('user', { name:'jessadapong rattana' })  
}

function one() {
    two()
    console.log('get===>', store.get('user'))
}

one()

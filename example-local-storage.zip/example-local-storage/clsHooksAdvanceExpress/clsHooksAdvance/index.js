const cls = require("cls-hooked");

const sessions = "Local Storage";

const middleware = (req, res, next) => {
  const ns = cls.getNamespace(sessions) || cls.createNamespace(sessions);
  ns.run(() => next());
};

const get = (key) => {
  const ns = cls.getNamespace(sessions);
  if (ns && ns.active) {
    return ns.get(key);
  }
};

const set = (key, value) => {
  const ns = cls.getNamespace(sessions);
  if (ns && ns.active) {
    return ns.set(key, value);
  }
};

module.exports = {
  middleware,
  get,
  set,
};

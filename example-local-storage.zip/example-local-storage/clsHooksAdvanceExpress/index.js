const express = require("express");
const clsHooksLocalstorage = require("./clsHooksAdvance");

const app = express();
const port = 3000;

function three() {
  const oldValue = clsHooksLocalstorage.get("areaName");
  clsHooksLocalstorage.set("areaName", {
    ...oldValue,
    areaCode: "123456",
  });
}

function two() {
  clsHooksLocalstorage.set("areaName", {
    areaName: "พื้นที่ราบ",
  });
  three();
}

app.use(clsHooksLocalstorage.middleware);

app.get("/", (req, res) => {
  two();
  res.send(clsHooksLocalstorage.get("areaName"));
});

app.listen(port, () => console.log(`listening at http://localhost:${port}`));

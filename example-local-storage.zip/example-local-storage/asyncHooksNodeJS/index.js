import  { AsyncLocalStorage } from 'async_hooks'

const asyncLocalStorage = new AsyncLocalStorage();

async function two() {
     console.log('ค่าคือ:=======>', asyncLocalStorage.getStore())
}

function one() {
    const res = 'jessadapong rattana'
    asyncLocalStorage.run( res, async()=>{
       await two()
    })
}

one()

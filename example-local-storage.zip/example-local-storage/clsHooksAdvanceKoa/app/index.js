const Koa = require("koa");
const router = require("../routes/routes");
const clsHooksLocalstorage = require("../clsHooksAdvance");

const app = new Koa();

app.use(clsHooksLocalstorage.middleware);
app.use(router.routes());

app.listen(3000);

const route = require("koa-router");
const clsHooksLocalstorage = require("../clsHooksAdvance");

const Router = new route();

function three() {
  const oldValue = clsHooksLocalstorage.get("areaName");
  clsHooksLocalstorage.set("areaName", {
    ...oldValue,
    areaCode: "123456",
  });
}

function two() {
  clsHooksLocalstorage.set("areaName", {
    areaName: "พื้นที่ราบ",
  });
  three();
}

Router.get("/", (ctx) => {
  two();
  ctx.body = clsHooksLocalstorage.get("areaName");
});

module.exports = Router;

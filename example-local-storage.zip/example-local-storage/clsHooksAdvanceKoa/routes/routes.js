const route = require("koa-router");
const clsHooksLocalstorage = require("../clsHooksAdvance");

const Router = new route();

function three() {
  const oldValue = clsHooksLocalstorage.get("oppLogs");
  clsHooksLocalstorage.set("oppLogs", {
    ...oldValue,
    areaCode: "123456",
  });
}

function two() {
  clsHooksLocalstorage.set("oppLogs", {
    areaName: "พื้นที่ราบ",
  });
  three();
}

Router.get("/", (ctx) => {
  two();
  ctx.body = clsHooksLocalstorage.get("oppLogs");
});

module.exports = Router;
